from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from db.database import init_db
from api import user, element, findrd, aitalk  # ← 필요한 라우터 추가

app = FastAPI()

# CORS 설정 (React에서 API 호출 가능하도록 허용)
origins = [
    "http://localhost:3000",  # React dev 서버
    "http://localhost:5173",  # Vite dev 서버
    "http://127.0.0.1:5173",
    # 배포 시 실제 도메인 추가
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],      # GET, POST, PUT, DELETE, OPTIONS 등 모두 허용
    allow_headers=["*"],      # 모든 헤더 허용
)

# DB 초기화
init_db()

# 라우터 등록
app.include_router(user.router, prefix="/api/user", tags=["user"])
app.include_router(element.router, prefix="/api/element", tags=["element"])
app.include_router(findrd.router, prefix="/api/findrd", tags=["findrd"])
app.include_router(aitalk.router, prefix="/api/aitalk", tags=["aitalk"])
